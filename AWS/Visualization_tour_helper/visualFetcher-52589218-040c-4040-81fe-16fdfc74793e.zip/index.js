console.log('Loading function');
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();
const s3 = new AWS.S3({ apiVersion: '2006-03-01' });
const dynamodb = new AWS.DynamoDB();



exports.handler = async (event, context) => {


    let body;
    let statusCode = '200';
    const headers = {
        'Content-Type': 'application/json',
    };

    try {

        let params = { TableName: "Feedbacks" };

        let scanResults = [];
        let items;

        do {
            items = await docClient.scan(params).promise();
            items.Items.forEach((item) => scanResults.push(item));
            params.ExclusiveStartKey = items.LastEvaluatedKey;
        } while (typeof items.LastEvaluatedKey != "undefined");
        var i = 0, j = 0, k = 0;
        var iip = 0, iin = 0, jjp = 0, jjn = 0, kkp = 0, kkn = 0;
        items.Items.forEach((item) => {
            if (item.feedbackType === 'Food') {
                i = i + 1;

                if (item.sentimentScore.toString().includes('-')) {
                    iin = iin + 1;
                    //iip = iip+ parseInt(item.sentimentScore);
                }
                else {
                    iip = iip + 1;
                }
            }
            if (item.feedbackType === 'Room') {
                j = j + 1;
                if (item.sentimentScore.toString().includes('-')) {
                    jjn = jjn + 1;
                    //iip = iip+ parseInt(item.sentimentScore);
                }
                else {
                    jjp = jjp + 1;
                }
            }
            if (item.feedbackType === 'Tour') {
                k = k + 1;
                if (item.sentimentScore.toString().includes('-')) {
                    kkn = kkn + 1;
                    //iip = iip+ parseInt(item.sentimentScore);
                }
                else {
                    kkp = kkp + 1;
                }
            }

        });
        // body = "FOOD:"+i+", ROOM:"+j+","+" TOUR:"+k+"," + "fp:"+iip+","+ "fn:"+iin+ "rp:"+jjp+","+ "rn:"+jjn+ "tp:"+kkp+","+ "tn:"+kkn;
        body = i + "," + j + "," + k + "," + iip + "," + iin + "," + jjp + "," + jjn + "," + kkp + "," + kkn + "," + (iip * 100) / (iip + iin) + "," + (jjp * 100) / (jjp + jjn) + "," + (kkp * 100) / (kkp + kkn);


    } catch (err) {
        statusCode = '400';
        body = err.message;
    } finally {
       body = JSON.stringify(body);
        return {
        statusCode,
        body,
        headers,
    };
        
    }

    
};
