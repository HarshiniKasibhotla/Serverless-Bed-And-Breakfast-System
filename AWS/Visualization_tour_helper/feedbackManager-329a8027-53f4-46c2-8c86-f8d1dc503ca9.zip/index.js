const AWS = require('aws-sdk');
const dynamodb = new AWS.DynamoDB();
const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event, context) => {
    
    
    let body;
    let statusCode = '200';
    const headers = {
        'Content-Type': 'application/json',
    };

    try {
       
            
        switch (event.requestContext.http.method) {
            case 'POST':     
                let requestJSON = JSON.parse(event.body);
                console.log(requestJSON);
                var params = {
                    TableName: "Feedbacks",
                    Item: {
                      feedbackType: requestJSON.feedbackType,
                      sentimentScore: requestJSON.sentimentScore,
                      booking_id: requestJSON.booking_id,
                      feedbackText: requestJSON.feedbackText,
                      timeStamp: Date.now()
                    }
                };
                
                await dynamo.put(params).promise();
                body = "success";
            
        
        }
        
    } catch (err) {
        statusCode = '400';
        body = err.message;
    } finally {
        body = body;
    }

    return {
        statusCode,
        body,
        headers,
    };
};
