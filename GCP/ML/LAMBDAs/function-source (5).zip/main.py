from google.cloud import aiplatform


def hello_world(request):
    if request.method == 'OPTIONS':
        # Allows GET requests from any origin with the Content-Type
        # header and caches preflight response for an 3600s
        headers = {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Max-Age': '3600'
        }

        return ('', 204, headers)


    
    
    request_json = request.get_json()
    instances=[{ "stay_duration": str(request_json['stay_duration'])}]

    aiplatform.init(project='1096471424321', location='us-east4')

    endpoint = aiplatform.Endpoint('6026836648212299776')
    ids = []
    response = endpoint.predict(instances=instances)
    print(type(response.predictions))
    print(response)
    print(response.predictions)
    for prediction_ in response.predictions:
        print(prediction_['scores'])
        i=0;
        for i in range(len(prediction_['scores'])):
            if(prediction_['scores'][i] > 0.11):
                ids.append(prediction_['classes'][i])
    
    print(ids)
    returnStr =''
    for x in ids:
        if(x=='1'):
            returnStr = returnStr + ' 1 , 1, 200, normal ,'
        if(x=='2'):
            returnStr = returnStr + ' 2 , 1 , 250, deluxe ,'
        if(x=='3'):
            returnStr = returnStr + ' 3 , 2 , 250,  normal ,'
        if(x=='4'):
            returnStr = returnStr + ' 4 , 2 , 300,  deluxe ,'
        if(x=='5'):
            returnStr = returnStr + ' 5 , 3 , 300,  normal ,'
        if(x=='6'):
            returnStr = returnStr + ' 6 , 3 , 350,  deluxe ,'
        if(x=='7'):
            returnStr = returnStr + ' 7 , 4 , 350,  normal ,'
        if(x=='8'):
            returnStr = returnStr + ' 8 , 4 , 400,  deluxe ,'
        if(x=='9'):
            returnStr = returnStr + ' 9 , 5 , 400,  normal ,'
        if(x=='10'):
            returnStr = returnStr + ' 10 , 5 , 450,  deluxe ,'
        if(x=='11'):
            returnStr = returnStr + ' 11 , 6 , 450,  normal ,'
        if(x=='12'):
            returnStr = returnStr + ' 12 , 6 , 500,  deluxe ,'
        if(x=='13'):
            returnStr = returnStr + ' 13 , 7 , 500,  normal ,'
        if(x=='14'):
            returnStr = returnStr + ' 14 , 7 , 550,  deluxe ,'
        if(x=='15'):
            returnStr = returnStr + ' 15 , 8 , 550,  normal ,'
        if(x=='16'):
            returnStr = returnStr + ' 16 , 8 , 600,  deluxe ,'
        if(x=='17'):
            returnStr = returnStr + ' 17 , 9 , 600,  normal ,'
        if(x=='18'):
            returnStr = returnStr + ' 18 , 9 , 650,  deluxe ,'
        if(x=='19'):
            returnStr = returnStr + ' 19 , 10 , 650,  normal ,'
        if(x=='20'):
            returnStr = returnStr + '20 , 10 , 700,  deluxe ,'
            
    
    headers = {
            'Access-Control-Allow-Origin': '*'
        } 
    return (returnStr[:-1],200,headers)